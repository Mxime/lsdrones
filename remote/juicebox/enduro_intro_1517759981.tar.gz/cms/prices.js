{
    test: {
		header: 'Super!',
		tagline: 'Génial',
	}
}