{
	users: [
		{
			username: 'maxime',
			tags: [],
			salt: 'e11ca6eb5ea829a0952e0e7e8378816f',
			hash: '78d79bbdf15235bb7c4ed6d638e349924389aa8ba1c7ac85533fb188f9967b6f',
			user_created_timestamp: 1517756795609
		}
	]
}